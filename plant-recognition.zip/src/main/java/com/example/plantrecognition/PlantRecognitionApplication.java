package com.example.plantrecognition;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlantRecognitionApplication {
    public static void main(String[] args) {
        SpringApplication.run(PlantRecognitionApplication.class, args);
    }
}